// pages/words/words.js
let baseurl = require('../../utils/global.js')
let globalUrl = baseurl.default.baseUrl
Page({

  /**
   * 页面的初始数据
   */
  data: {
    collectBook: '',
    bookList: [{
        bookId: 4,
        type: '四级英语'
      },
      {
        bookId: 6,
        type: '六级英语'
      }
    ],
    id: '',

  },
  // 选择哪本单词（目前只提供四六级）
  tapName: function(e) {
    console.log(e)
    const num = e.currentTarget.id;
    console.log(this.data.bookList[num].type)
    wx.request({
      url: globalUrl + '/word/wordBook',
      data: {
        uid: this.data.id,
        bookId: this.data.bookList[num].bookId
      },
      method: 'POST',
      header: {
        'content-type': 'application/x-www-form-urlencoded' // 默认值
      },
      success(res) {
        console.log(res.data)
        if (res.data.code === 200) {
          wx.showModal({
            title: '提示',
            content: '选择成功',
            showCancel: false,
            success(res) {
              if (res.confirm) {
                console.log('用户点击确定')
                wx.navigateBack({
                  delta: 2
                })
              }
            }
          })
        }
      }
    })
    this.setData({
      collectBook: this.data.bookList[num].type
    })
    wx.setStorageSync('wordbook', this.data.collectBook)
  },
  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function(options) {
    var value = wx.getStorageSync('userinfo')
    if (value) {
      console.log(value)
      this.setData({
        id: value.id
      })
    }
    console.log(this.data.id)
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function() {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function() {
    let that = this;
    var value = wx.getStorageSync('wordbook')
    if (value) {
      console.log(value)
    }
    wx.getStorage({
      key: 'wordbook',
      success(res) {
        console.log(res.data)
        that.setData({
          collectBook: res.data
        })
      }
    })
  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function() {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function() {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function() {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function() {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function() {

  }
})