// pages/study/study.js
let baseurl = require('../../utils/global.js')
let globalUrl = baseurl.default.baseUrl
Page({

  /**
   * 页面的初始数据
   */
  data: {
    todayNum: 1,
    total: 20,
    wordArray: [{
        id: 1,
        num: 1,
        word: 'eehhhh'
      },
      {
        id: 2,
        num: 2,
        word: '1dd11'
      },
      {
        id: 3,
        num: 3,
        word: 'ddddffdg'
      },
      {
        id: 4,
        num: 4,
        word: 'ghjyuhmh'
      },
    ],
    condition: true,
    word: '',
    numData: 0,
    phone: '',
    num: '',
    id: '',
    phone: '',
    status: '', // 点击不认识，认识，太简单了的状态
    message: '',
    easy: true,
    know: true,
    noknow: true,
    soundMark: ''
  },
  // 点击收藏单词
  clickConfirm: function() {
    // this.setData({
    //   condition: false
    // })
    let that = this;
    console.log(that.data.wordArray[that.data.todayNum - 1].wid)
    console.log(that.data.phone)
    wx.request({
      url: globalUrl + '/collect/save', //接口地址
      data: {
        wid: that.data.wordArray[that.data.todayNum - 1].wid,
        phone: that.data.phone
      },
      method: 'POST',
      header: {
        'content-type': 'application/x-www-form-urlencoded' // 默认值
      },
      success(res) {
        console.log(res.data)
        if (res.data.code === 200) {
          that.setData({
            condition: false,
          })
          wx.showToast({
            title: '收藏成功！', // 标题
            icon: 'success', // 图标类型，默认success
            duration: 1000 // 提示窗停留时间，默认1500ms
          })
          // that.clickNext();
        } else if (res.data.code === 400) {
          that.setData({
            condition: false
          })
          wx.showToast({
            title: '已经收藏', // 标题
            icon: 'success', // 图标类型，默认success
            duration: 1000 // 提示窗停留时间，默认1500ms
          })
        }
      }
    })
  },
  // 点击太简单了
  easyClick: function() {
    this.setData({
      status: 0,
      easy: false,
    })
    this.record();
  },
  // 点击认识
  knowClick: function(e) {
    this.setData({
      status: 1,
      know: false,
    })
    this.record();
  },
  // 点击不认识
  noknowClick: function() {
    // let that = this;
    this.setData({
      status: 2,
      noknow: false,
      condition: false
    })
    this.record();
  },
  // 挑战下一个
  clickNext: function() {
    let that = this;
    that.data.numData = that.data.numData + 1;
    let i = that.data.numData;
    console.log('初始化', that.data.numData)
    if (i - 1 === that.data.wordArray.length) {
      that.setData({
        word: that.data.wordArray[that.data.todayNum - 1].wordName,
        condition: true
      })
      wx.showModal({
        title: '目标达成',
        content: '今日目标已完成',
        showCancel: false,
        success: function(res) {
          if (res.confirm) {
            console.log('用户点击确定')
            wx.navigateBack({
              delta: 2
            })
          }
        }
      })
      return;
    }
    that.setData({
      todayNum: i,
      word: that.data.wordArray[i - 1].wordName,
      condition: true,
      message: '',
      soundMark: '',
      easy: true,
      know: true,
      noknow: true
    })
  },
  // 保存学习记录
  record: function() {
    let that = this;
    wx.request({
      url: globalUrl + '/word/study', //接口地址
      data: {
        wid: that.data.wordArray[that.data.todayNum - 1].wid,
        uid: that.data.id,
        stuCorrect: that.data.status,
        phone: that.data.phone
      },
      method: 'POST',
      header: {
        'content-type': 'application/x-www-form-urlencoded' // 默认值
      },
      success(res) {
        console.log(res.data)
        // that.clickNext();
        that.setData({
          message: that.data.wordArray[that.data.todayNum - 1].explainWord,
          soundMark: that.data.wordArray[that.data.todayNum - 1].soundMark,
        })
        console.log(that.data.message)
      }
    })
  },
  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function(options) {
    let that = this;
    var value = wx.getStorageSync('plan')
    console.log(value)
    if (value) {
      console.log(value)
      that.setData({
        num: value
      })
      let i = that.data.numData;
      wx.request({ // 请求单词数据
        url: globalUrl + '/word/text',
        data: {
          num: that.data.num
        },
        method: 'GET',
        header: {
          'content-type': 'application/x-www-form-urlencoded' // 默认值
        },
        success(res) {
          console.log(res.data, i)
          if (res.data.code === 200) {
            that.setData({
              wordArray: res.data.data,
              word: res.data.data[i].wordName
            })
            console.log(that.data.word)
          }
        }
      })
    }
    console.log(that.data.wordArray[0].word, that.data.todayNum);
    this.setData({ // 页面初始化数据
      numData: 1,
      word: that.data.wordArray[0].word,
      total: that.data.wordArray.length
    })
    var value = wx.getStorageSync('userinfo')
    if (value) {
      console.log(value)
      that.setData({
        id: value.id,
        phone: value.phone
      })
    }

  },


  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function() {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function() {
    let that = this;
    var value = wx.getStorageSync('userinfo')
    if (value) {
      console.log(value)
      that.setData({
        phone: value.phone
      })
    }
  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function() {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function() {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function() {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function() {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function() {

  }
})