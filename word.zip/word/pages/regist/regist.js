// pages/regist/regist.js
let baseurl = require('../../utils/global.js')
let globalUrl = baseurl.default.baseUrl
Page({

  /**
   * 页面的初始数据
   */
  data: {
    phone: '',
    password: '',
  },
  // 提交注册数据
  formSubmit: function(e) {
    console.log('form发生了submit事件，携带数据为：', e.detail.value);
    if (e.detail.value.phone === '' && e.detail.value.phone.length < 11) { // 检验手机号是否输入或者手机号是否输入有误
      wx.showModal({
        title: '提示',
        content: '手机号填写有误',
        showCancel: false,
        success(res) {
          if (res.confirm) {
            console.log('用户点击确定')
          }
        }
      })
    } else if (e.detail.value.password.length < 6) {
      wx.showModal({
        title: '提示',
        content: '密码应不小于6位',
        showCancel: false,
        success(res) {
          if (res.confirm) {
            console.log('用户点击确定')
          }
        }
      })
    } else {
      wx.request({
        url: globalUrl + '/user/save',
        data: {
          phone: e.detail.value.phone,
          password: e.detail.value.password
        },
        method: 'POST',
        header: {
          'content-type': 'application/x-www-form-urlencoded' // 默认值
        },
        success(res) {
          console.log(res.data)
          if (res.data.code === 200) {
            let value = wx.getStorageSync('userinfo');
            if (value) {
              console.log(value)
              value.phone = e.detail.value.phone
            }
            console.log(value)
            const data = {
              phone: value.phone,
              username: value.username,
              mysign: value.mysign
            }
            wx.setStorageSync('userinfo', data)
            wx.showModal({
              title: '提示',
              content: '注册成功',
              showCancel: false,
              success(res) {
                if (res.confirm) {
                  console.log('用户点击确定')
                  wx.redirectTo({
                    url: '../login/login',
                  })
                }
              }
            })
          } else if (res.data.code === 400) {
            wx.showModal({
              title: '提示',
              content: '手机号被注册，请重新填写',
              showCancel: false,
              success(res) {
                if (res.confirm) {
                  console.log('用户点击确定')
                }
              }
            })
          }
        }
      })
    }
  },
  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function(options) {
    wx.showModal({
      title: '提示',
      content: '新用户请先注册，老用户可直接登录',
      showCancel: false,
      success(res) {
        if (res.confirm) {
          console.log('用户点击确定')
        }
      }
    })
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function() {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function() {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function() {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function() {},

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function() {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function() {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function() {

  }
})