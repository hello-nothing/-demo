// pages/search/search.js
let baseurl = require('../../utils/global.js')
let globalUrl = baseurl.default.baseUrl
Page({

  /**
   * 页面的初始数据
   */
  data: {
    dataInput: '',
    result: '', // 翻译结果
    chineseResult: {
      wordName: '',
      soundMark: '',
      explainWord: ''
    }, // 查询英文单词后的结果
    nullData: 
    {
      wordName: '暂无查询结果',
      soundMark: '暂无查询结果',
      explainWord: '暂无查询结果'
    },
  },
  // 搜索中英文
  getInputValue(e) {
    let that = this;
    console.log(e.detail)
    that.setData({
      dataInput: e.detail.data
    })
    wx.request({
      url: globalUrl + '/tran/search', //接口地址
      data: {
        content: e.detail.value,
      },
      header: {
        'content-type': 'application/json' // 默认值
      },
      success(res) {
        console.log(res.data)
        if (res.data.code === 200) {
          wx.showToast({
            title: '翻译成功',
            icon: 'success',
            duration: 2000
          })
          that.setData({
            result: res.data.data
          })
        } else {
          wx.showToast({
            title: '暂无查询结果',
            icon: 'fail',
            duration: 2000
          })
          that.setData({
            result: '暂无查询结果'
          })
        }
      }
    })
  },
  // 搜索英文
  getChineseValue(e) {
    let that = this;
    console.log(e.detail)
    that.setData({
      dataInput: e.detail.data
    })
    wx.request({
      url: globalUrl + '/word/queryWord', //接口地址
      data: {
        wordName: e.detail.value,
      },
      header: {
        'content-type': 'application/json' // 默认值
      },
      success(res) {
        console.log(res.data)
        if (res.data.code === 200) {
          wx.showToast({
            title: '查询成功',
            icon: 'success',
            duration: 2000
          })
          that.setData({
            chineseResult: res.data.data
          })
        } else {
          wx.showToast({
            title: '暂无查询结果',
            icon: 'fail',
            duration: 2000
          })
          that.setData({
            chineseResult: that.data.nullData
          })
        }
      }
    })
  },
  // 点击搜索
  searchButton: function() {
    console.log(e)
    this.getInputValue();
  },
  // 点击查询
  checkButton: function() {
    console.log(e)
    this.getChineseValue();
  },
  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function(options) {

  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function() {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function() {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function() {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function() {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function() {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function() {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function() {

  }
})