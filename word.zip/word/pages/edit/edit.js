// pages/edit/edit.js
let baseurl = require('../../utils/global.js')
let globalUrl = baseurl.default.baseUrl
Page({

  /**
   * 页面的初始数据
   */
  data: {
    phone: '',
    username: '',
    mysign: ''
  },
  // 提交信息数据
  formSubmit: function(e) {
    console.log('form发生了submit事件，携带数据为：', e.detail.value);
    wx.request({
      url: globalUrl + '/user/updateUserInfo', // 接口地址
      data: { // 参数
        phone: e.detail.value.phone,
        username: e.detail.value.username,
        mysign: e.detail.value.mysign
      },
      method: 'POST', // 方法
      header: {
        'content-type': 'application/x-www-form-urlencoded' // 默认值
      },
      success(res) {
        console.log(res.data)
        if (res.data.code === 200) {
          wx.showModal({
            title: '提示',
            content: '完善成功',
            showCancel: false,
            success(res) {
              if (res.confirm) {
                console.log('用户点击确定')
                wx.navigateBack({
                  delta: 2
                })
              }
            }
          })
          wx.setStorageSync('userinfo', e.detail.value) // 缓存信息数据，返回后取出来展示
        }
      }
    })

  },
  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function(options) {

  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function() {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function() {
    let that = this;
    var value = wx.getStorageSync('userinfo') // 下次进入信息编辑时会显示上次数据
    if (value) {
      console.log(value)
      that.setData({
        phone: value.phone,
        username: value.username,
        mysign: value.mysign
      })
    }
  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function() {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function() {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function() {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function() {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function() {

  }
})