// pages/collect-word/collect.js
let baseurl = require('../../utils/global.js')
let globalUrl = baseurl.default.baseUrl
Page({

  /**
   * 页面的初始数据
   */
  data: {
    wordsArray: [],
    phone: ''

  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function(options) {
    let that = this;
    var value = wx.getStorageSync('userinfo')
    if (value) {
      console.log(value)
      that.setData({
        phone: value.phone
      })
    }
    // 查询我收藏的单词
    console.log(that.data.phone)
    wx.request({
      url: globalUrl + '/collect/queryMyCollect', //接口地址
      data: {
        phone: that.data.phone
      },
      header: {
        'content-type': 'application/json' // 默认值
      },
      success(res) {
        console.log(res.data)
        if (res.data.code === 200) {
          that.setData({
            wordsArray: res.data.data
          })
        } else {
          wx.showToast({
            title: '暂无收藏单词', // 标题
            icon: 'none', // 图标类型，默认success
            duration: 1000 // 提示窗停留时间，默认1500ms
          })
        }
      }
    })
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function() {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function() {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function() {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function() {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function() {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function() {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function() {

  }
})