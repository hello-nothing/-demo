//logs.js
let baseurl = require('../../utils/global.js')
let globalUrl = baseurl.default.baseUrl
Page({

  /**
   * 页面的初始数据
   */
  data: {
    todayNum: 1,
    total: 20,
    wordArray: [{
        num: 1,
        wordName: 'eehhhh'
      },
      {
        num: 2,
        wordName: '1dd11'
      },
      {
        num: 3,
        wordName: 'ddddffdg'
      },
      {
        num: 4,
        wordName: 'ghjyuhmh'
      },
    ],
    condition: true, // 控制是否收藏的显示
    noStart: true, // 控制选择单词数量之前的页面显示
    word: '', // 单词展示
    numData: 0, // 
    array: [10, 25, 50], // 每次可选挑战单词数量
    collectWord: true,
    index: 0,
    phone: '',
    message: '',
    soundMark: ''

  },
  // 选择挑战单词数量
  bindPickerChange: function(e) {
    console.log('picker发送选择改变，携带值为', e.detail.value)
    this.setData({
      index: e.detail.value,
      collectWord: false
    })
  },
  // 点击开始挑战
  startChallenge: function() {
    let that = this;
    that.setData({
      noStart: false
    })
    let i = that.data.numData;
    console.log(i)
    wx.request({
      url: globalUrl + '/word/text',
      data: {
        num: that.data.array[that.data.index]
      },
      method: 'GET',
      header: {
        'content-type': 'application/x-www-form-urlencoded' // 默认值
      },
      success(res) {
        console.log(res.data)
        if (res.data.code === 200) {
          that.setData({
            wordArray: res.data.data, // 挑战单词数据列表
            word: res.data.data[i - 1].wordName
          })
          console.log(that.data.word)
        }
      }
    })
  },
  // 点击不认识,收藏
  clickConfirm: function() {

    let that = this;
    console.log(that.data.wordArray[that.data.todayNum - 1].wid)
    console.log(that.data.phone)
    wx.request({
      url: globalUrl + '/collect/save', //接口地址
      data: {
        wid: that.data.wordArray[that.data.todayNum - 1].wid,
        phone: that.data.phone
      },
      method: 'POST',
      header: {
        'content-type': 'application/x-www-form-urlencoded' // 默认值
      },
      success(res) {
        console.log(res.data)
        if (res.data.code === 200) {
          wx.showToast({
            title: '收藏成功！', // 标题
            icon: 'success', // 图标类型，默认success
            duration: 1000 // 提示窗停留时间，默认1500ms
          })
          that.setData({
            message: that.data.wordArray[that.data.todayNum - 1].explainWord,
            soundMark: that.data.wordArray[that.data.todayNum - 1].soundMark,
            condition: false
          })
          // that.clickNext();
        } else if (res.data.code === 400) {
          that.setData({
            condition: false
          })
          wx.showToast({
            title: '已经收藏', // 标题
            icon: 'success', // 图标类型，默认success
            duration: 2000 // 提示窗停留时间，默认1500ms
          })

        }
      }
    })
  },
  // 点击太简单了，认识
  clickNext: function() {
    let that = this;
    that.data.numData = that.data.numData + 1;
    let i = that.data.numData;
    console.log('初始化', that.data.numData)
    console.log(that.data.wordArray, i)
    if (i - 1 === that.data.wordArray.length) {
      that.setData({
        word: that.data.wordArray[that.data.todayNum - 1].wordName,
        condition: true
      })
      console.log('_______')
      wx.showModal({
        title: '挑战成功',
        content: '挑战成功，是否再来一局',
        success: function(res) {
          if (res.confirm) {
            console.log('用户点击确定')
            that.setData({
              collectWord: true
            })
          } else {
            console.log('用户点击取消')
            that.setData({
              collectWord: true
            })
          }
        }
      })
      return;
    }
    that.setData({
      todayNum: i,
      word: that.data.wordArray[i - 1].wordName,
      condition: true,
      message: '',
      soundMark: ''
    })
  },
  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function(options) {
    console.log(this.data.wordArray[0].word, this.data.todayNum);
    this.setData({ // 页面初始化数据
      numData: 1,
      word: this.data.wordArray[0].word,
      total: this.data.wordArray.length
    })
    this.data.word = this.data.wordArray[0].word;
    var value = wx.getStorageSync('userinfo')
    if (value) {
      console.log(value)
      this.setData({
        phone: value.phone, // 获取用户手机号
      })
    }
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function() {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function() {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function() {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function() {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function() {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function() {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function() {

  }
})