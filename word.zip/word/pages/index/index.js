//index.js
//获取应用实例
const app = getApp()
let baseurl = require('../../utils/global.js')
let globalUrl = baseurl.default.baseUrl
let hasLogin = baseurl.default.hasLogin


Page({
  data: {
    planWord: 0, // 今日计划单词数量
    haveWord: 0, // 今日已学单词数量
    studyNum: 0, // 学习天数
    // completeWord: '33333',
    totalWord: '0', // 本书总计单词数量
    // shengyuNum: '33333',
    thisBook: '当前所背书',
    id: '',
    bookList: [{
        bookId: 4,
        type: '四级英语'
      },
      {
        bookId: 6,
        type: '六级英语'
      }
    ],
    bookId: 4,
    phone: ''
  },
  //事件处理函数 跳转至选单词书页面
  collectBook: function() {
    wx.navigateTo({
      url: '../words/words',
    })
  },
  goPlan: function() {
    wx.navigateTo({
      url: '../study-plan/study-plan',
    })
  },
  // 跳转至每日学习单词页面
  startStudy: function() {
    let that = this;
    var value = wx.getStorageSync('plan')
    console.log(value)
    if (value) {
      wx.navigateTo({
        url: '../study/study',
      })
    } else {
      wx.showModal({
        title: '提示',
        content: '请选择每日计划数量',
        showCancel: false,
        success(res) {
          if (res.confirm) {
            console.log('用户点击确定')
            wx.navigateTo({
              url: '../study-plan/study-plan',
            })
          }
        }
      })
    }
  },
  // 获取今日计划，今日已学，学习天数 的数据
  getsudy: function() {
    let that = this;
    wx.request({
      url: globalUrl + '/user/userReport',
      data: {
        uid: that.data.id,
      },
      method: 'POST',
      header: {
        'content-type': 'application/x-www-form-urlencoded' // 默认值
      },
      success(res) {
        console.log(res.data)
        if (res.data.code === 200) {
          that.setData({
            planWord: res.data.data.wordCount, // 今日计划
            haveWord: res.data.data.todayStuWord, // 今日已学
            studyNum: res.data.data.studyDay, // 学习天数
            totalWord: res.data.data.wordBookNum, // 本书单词数量
          })
          var value = wx.getStorageSync('plan') // 获取每日计划数量
          if (value) {
            console.log(value)
            that.setData({
              planWord: value
            })
          }
        }
      }
    })
  },
  // 默认选择四级
  getword: function() {
    let that = this;
    wx.request({
      url: globalUrl + '/word/wordBook',
      data: {
        uid: that.data.id,
        bookId: that.data.bookId,
        phone: that.data.phone
      },
      method: 'POST',
      header: {
        'content-type': 'application/x-www-form-urlencoded' // 默认值
      },
      success(res) {
        console.log(res.data)
        if (res.data.code === 200) {
          that.setData({
            thisBook: that.data.bookList[0].type
          })
        }
      }
    })
  },
  onLoad: function() {
    if (app.globalData.userInfo) {
      this.setData({
        userInfo: app.globalData.userInfo,
        hasUserInfo: true
      })
    } else if (this.data.canIUse) {
      // 由于 getUserInfo 是网络请求，可能会在 Page.onLoad 之后才返回
      // 所以此处加入 callback 以防止这种情况
      app.userInfoReadyCallback = res => {
        this.setData({
          userInfo: res.userInfo,
          hasUserInfo: true
        })
      }
    } else {
      // 在没有 open-type=getUserInfo 版本的兼容处理
      wx.getUserInfo({
        success: res => {
          app.globalData.userInfo = res.userInfo
          this.setData({
            userInfo: res.userInfo,
            hasUserInfo: true
          })
        }
      })
    };
  },
  onShow: function() {
    console.log(hasLogin)
    let status = wx.getStorageSync('loginStatus') // 获取登录状态
    if (status) {
      hasLogin = status;
    }
    let that = this;
    if (!hasLogin) {
      wx.showModal({
        title: '提示',
        content: '为确保账号安全，需用手机号登录',
        showCancel: false,
        success(res) {
          if (res.confirm) {
            console.log('用户点击确定')
            wx.redirectTo({
              url: '../regist/regist', // 跳转注册页面
            })
          }
        }
      })
    }
    var word = wx.getStorageSync('wordbook') // 获取当前所选哪本单词
    if (word) {
      console.log(word)
      that.setData({
        thisBook: word
      })
    }
    var value = wx.getStorageSync('userinfo') // 获取当前账户信息
    if (value) {
      console.log(value)
      that.setData({
        id: value.id,
        phone: value.phone
      })
      this.getsudy();
      this.getword();
    }
  },
  getUserInfo: function(e) {
    console.log(e)
    app.globalData.userInfo = e.detail.userInfo
    this.setData({
      userInfo: e.detail.userInfo,
      hasUserInfo: true
    })
  }
})