// pages/login/login.js
let baseurl = require('../../utils/global.js')
let globalUrl = baseurl.default.baseUrl
let hasLogin = baseurl.default.hasLogin
console.log(hasLogin)
Page({

  /**
   * 页面的初始数据
   */
  data: {
    phone: '',
    password: '',
  },
  // 提交登录数据
  formSubmit: function(e) {
    if (e.detail.value.phone === '' && e.detail.value.phone.length < 11) { // 检验手机号是否输入或者手机号是否输入有误
      wx.showModal({
        title: '提示',
        content: '手机号填写有误',
        showCancel: false,
        success(res) {
          if (res.confirm) {
            console.log('用户点击确定')
          }
        }
      })
    } else if (e.detail.value.password.length < 6) { // 检验密码位数
      wx.showModal({
        title: '提示',
        content: '密码应不小于6位',
        showCancel: false,
        success(res) {
          if (res.confirm) {
            console.log('用户点击确定')
          }
        }
      })
    } else {
      wx.request({
        url: globalUrl + '/user/login',
        data: {
          phone: e.detail.value.phone,
          password: e.detail.value.password
        },
        method: 'POST',
        header: {
          'content-type': 'application/x-www-form-urlencoded' // 默认值
        },
        success(res) {
          console.log(res.data)
          if (res.data.code === 200) {
            hasLogin = true;
            wx.setStorageSync('loginStatus', hasLogin); // 存储登录状态
            wx.setStorageSync('userinfo', res.data.data); // 存储登录信息
            wx.showModal({
              title: '提示',
              content: '登录成功',
              showCancel: false,
              success(res) {
                if (res.confirm) {
                  console.log('用户点击确定')
                  wx.switchTab({
                    url: '../my/my',
                  })
                }
              }
            })
          } else if (res.data.code === 400) {
            if (res.data.msg == '密码错误') {
              wx.showModal({
                title: '提示',
                content: '密码错误',
                showCancel: false,
                success(res) {
                  if (res.confirm) {
                    console.log('用户点击确定')
                    // wx.navigateTo({
                    //   url: '../regist/regist',
                    // })
                  }
                }
              })
            } else {
              wx.showModal({
                title: '提示',
                content: '密码错误三次，请联系右下方管理员QQ',
                showCancel: false,
                success(res) {
                  if (res.confirm) {
                    console.log('用户点击确定')
                    // wx.makePhoneCall({
                    //   phoneNumber: '15037268535' //管理员电话号码
                    // })
                  }
                }
              })
            }

          }
        }
      })
    }
  },
  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function(options) {
    let value = wx.getStorageSync('userinfo'); // 二次进入页面时自动获取手机号
    if (value) {
      console.log(value)
      this.setData({
        phone: value.phone
      })
    }
    wx.showModal({
      title: '提示',
      content: '新用户请先注册，老用户可直接登录',
      showCancel: false,
      success(res) {
        if (res.confirm) {
          console.log('用户点击确定')
        }
      }
    })
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function() {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function() {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function() {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function() {},

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function() {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function() {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function() {

  }
})