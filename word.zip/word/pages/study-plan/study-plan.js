// pages/study-plan/study-plan.js
let baseurl = require('../../utils/global.js')
let globalUrl = baseurl.default.baseUrl
Page({

  /**
   * 页面的初始数据
   */
  data: {
    number: '200',
    array: [10, 20, 30, 40],
    index: 0,
    id: '',
    phone: ''
  },
  // 获取每日计划数量
  bindPickerChange: function(e) {
    console.log('picker发送选择改变，携带值为', e.detail.value)
    this.setData({
      index: e.detail.value
    })
    // 缓存计划数量
    wx.setStorageSync('plan', this.data.array[this.data.index])
  },
  // 点击确定
  confirm: function() {
    let that =this;
    console.log(that.data.array[that.data.index])
    wx.request({
      url: globalUrl + '/user/savePlan', //接口地址
      data: {
        wordCount: that.data.array[that.data.index],
        uid: that.data.id,
        phone: that.data.phone
      },
      method: 'post',
      header: {
        'content-type': 'application/x-www-form-urlencoded' // 默认值
      },
      success(res) {
        console.log(res)
        if (res.data.code === 200) {
          wx.showToast({
            title: '选择成功',
            duration: 3000
          })
          wx.setStorageSync('plan', that.data.array[that.data.index])
          wx.navigateBack({
            delta: 2
          })
        }
      }
    })

  },
  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function(options) {
    var value = wx.getStorageSync('userinfo')
    if (value) {
      console.log(value)
      this.setData({
        id: value.id,
        phone: value.phone
      })
    }
    console.log(this.data.id)
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function() {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function() {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function() {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function() {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function() {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function() {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function() {

  }
})