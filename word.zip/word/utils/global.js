export default {
  baseUrl: 'http://47.103.132.196:8777', // 请求地址
  hasLogin: false
}
